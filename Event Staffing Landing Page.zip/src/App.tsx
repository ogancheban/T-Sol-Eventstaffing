"use client";

import { useEffect } from "react";
import { motion } from "motion/react";
import Header from "./components/Header";
import HeroSection from "./components/HeroSection";
import AboutSection from "./components/AboutSection";
import ServicesSection from "./components/ServicesSection";
import PricingSection from "./components/PricingSection";
import EventTypesSection from "./components/EventTypesSection";
import ServiceAreasSection from "./components/ServiceAreasSection";
import HowItWorksSection from "./components/HowItWorksSection";
import GallerySection from "./components/GallerySection";
import FAQSection from "./components/FAQSection";
import ContactSection from "./components/ContactSection";
import Footer from "./components/Footer";

export default function App() {
  useEffect(() => {
    // Smooth scrolling behavior
    document.documentElement.style.scrollBehavior = "smooth";
    
    // Add class for dark theme
    document.documentElement.classList.add("dark");
    
    return () => {
      document.documentElement.style.scrollBehavior = "auto";
    };
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <Header />
      
      {/* Main Content */}
      <main>
        <HeroSection />
        <AboutSection />
        <ServicesSection />
        <PricingSection />
        <EventTypesSection />
        <ServiceAreasSection />
        <HowItWorksSection />
        <GallerySection />
        <FAQSection />
        <ContactSection />
      </main>
      
      {/* Footer */}
      <Footer />
      
      {/* Scroll to top button */}
      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="fixed bottom-8 right-8 w-12 h-12 bg-white text-black rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors z-40"
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      >
        ↑
      </motion.button>
    </div>
  );
}