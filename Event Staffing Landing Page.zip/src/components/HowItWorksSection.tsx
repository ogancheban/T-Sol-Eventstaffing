"use client";

import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { MessageSquare, CheckCircle, Users } from "lucide-react";
import { Button } from "./ui/button";

const HowItWorksSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  const steps = [
    {
      number: "01",
      icon: MessageSquare,
      title: "Tell Us About Your Event",
      description: "Share the date, location, guest count, and type of service you need.",
      color: "from-blue-500 to-blue-700"
    },
    {
      number: "02", 
      icon: CheckCircle,
      title: "Confirm & Book",
      description: "We provide a clear estimate and reserve your staff.",
      color: "from-green-500 to-green-700"
    },
    {
      number: "03",
      icon: Users,
      title: "Relax & Enjoy",
      description: "Our team arrives on time and handles service, setup, and cleanup.",
      color: "from-purple-500 to-purple-700"
    }
  ];

  const faqs = [
    { question: "Minimum booking?", answer: "4 hours" },
    { question: "Areas served?", answer: "Sacramento + Bay Area" },
    { question: "Staff insured?", answer: "Yes, fully insured and background-checked" }
  ];

  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section ref={ref} className="py-24 bg-gray-950">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-6xl font-bold text-white mb-6">
              Stress-Free Staffing in{" "}
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                3 Simple Steps
              </span>
            </h2>
          </motion.div>

          {/* Steps */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {steps.map((step, index) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.2 + index * 0.2 }}
                className="relative group"
              >
                {/* Connector Line */}
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-16 left-full w-full h-0.5 bg-gradient-to-r from-gray-600 to-transparent z-0"></div>
                )}

                <div className="relative bg-black/50 backdrop-blur-sm border border-gray-800 rounded-xl p-8 text-center hover:scale-105 transition-all duration-300 hover:border-gray-600 z-10">
                  {/* Step Number */}
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className={`w-8 h-8 bg-gradient-to-r ${step.color} rounded-full flex items-center justify-center`}>
                      <span className="text-white font-bold text-sm">{step.number}</span>
                    </div>
                  </div>

                  {/* Icon */}
                  <div className={`inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r ${step.color} rounded-full mb-6 mt-4`}>
                    <step.icon className="w-8 h-8 text-white" />
                  </div>

                  {/* Content */}
                  <h3 className="text-xl font-bold text-white mb-4">{step.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* FAQ Teaser */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="bg-gray-900/30 backdrop-blur-sm border border-gray-800 rounded-xl p-8 mb-12"
          >
            <h3 className="text-2xl font-bold text-white mb-6 text-center">Quick Answers</h3>
            <div className="grid md:grid-cols-3 gap-6">
              {faqs.map((faq, index) => (
                <div key={index} className="text-center">
                  <p className="text-gray-400 mb-2">{faq.question}</p>
                  <p className="text-white font-semibold">{faq.answer}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 1 }}
            className="text-center"
          >
            <p className="text-gray-400 mb-6">Ready to hire staff?</p>
            <Button
              onClick={scrollToContact}
              size="lg"
              className="bg-white text-black hover:bg-gray-200 transition-all duration-300 transform hover:scale-105 px-8 py-6"
            >
              Get a Free Quote Today
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;