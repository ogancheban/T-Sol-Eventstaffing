"use client";

import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { 
  Users, 
  Wine, 
  UserCheck, 
  Handshake, 
  Settings, 
  ChefHat, 
  Megaphone 
} from "lucide-react";
import { Button } from "./ui/button";

const ServicesSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  const services = [
    {
      icon: Users,
      title: "Waitstaff",
      description: "Polished and attentive servers who bring restaurant-quality service to your event.",
      features: ["Professional appearance", "Fine dining experience", "Customer service focus"]
    },
    {
      icon: Wine,
      title: "Bartenders",
      description: "Experienced mixologists ready to craft cocktails, pour wine, and keep the drinks flowing.",
      features: ["Certified mixologists", "Wine expertise", "Professional bar setup"]
    },
    {
      icon: UserCheck,
      title: "Event Captains & Supervisors",
      description: "On-site leaders who manage staff and coordinate service so you don't have to worry.",
      features: ["Team leadership", "Service coordination", "Problem resolution"]
    },
    {
      icon: Handshake,
      title: "Hosts & Guest Services",
      description: "Friendly professionals to greet guests, assist with seating, and manage check-ins.",
      features: ["Guest welcoming", "Seating coordination", "Information assistance"]
    },
    {
      icon: Settings,
      title: "Setup & Breakdown Crew",
      description: "Dependable team members who handle event setup, teardown, and cleanup with efficiency.",
      features: ["Event setup", "Teardown service", "Cleanup coordination"]
    },
    {
      icon: ChefHat,
      title: "Catering & Kitchen Support",
      description: "Bussers, runners, and dishwashers to support chefs and caterers behind the scenes.",
      features: ["Kitchen assistance", "Food running", "Dishwashing service"]
    },
    {
      icon: Megaphone,
      title: "Brand Ambassadors & Promo Staff",
      description: "Engaging promotional models for product launches, trade shows, and brand activations.",
      features: ["Brand representation", "Product promotion", "Event engagement"]
    }
  ];

  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="services" ref={ref} className="py-24 bg-gray-950">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-6xl font-bold text-white mb-6">
              Professional{" "}
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Services
              </span>
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              From intimate gatherings to large-scale corporate events, our trained staff ensures 
              every detail runs smoothly.
            </p>
          </motion.div>

          {/* Services Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
                className="group"
              >
                <div className="bg-black/50 backdrop-blur-sm border border-gray-800 rounded-xl p-6 h-full hover:bg-gray-900/50 transition-all duration-300 hover:scale-105 hover:border-gray-600">
                  {/* Icon */}
                  <div className="flex items-center justify-center w-14 h-14 bg-gradient-to-r from-white to-gray-300 rounded-xl mb-6 group-hover:scale-110 transition-transform duration-300">
                    <service.icon className="w-7 h-7 text-black" />
                  </div>

                  {/* Content */}
                  <h3 className="text-xl font-bold text-white mb-3">{service.title}</h3>
                  <p className="text-gray-400 mb-4 leading-relaxed">{service.description}</p>

                  {/* Features */}
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-2 text-sm text-gray-500">
                        <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            ))}
          </div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="text-center"
          >
            <Button
              onClick={scrollToContact}
              size="lg"
              className="bg-white text-black hover:bg-gray-200 transition-all duration-300 transform hover:scale-105 px-8 py-6"
            >
              Get Custom Quote for Your Event
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;