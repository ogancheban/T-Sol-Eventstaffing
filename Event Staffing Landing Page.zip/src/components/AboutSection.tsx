"use client";

import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { Users, Award, Heart, Zap } from "lucide-react";

const AboutSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  const values = [
    {
      icon: Users,
      title: "Professionalism",
      description: "Every team member is trained, punctual, and guest-focused."
    },
    {
      icon: Award,
      title: "Reliability",
      description: "We show up prepared and ready — no last-minute surprises."
    },
    {
      icon: Heart,
      title: "Community",
      description: "We support local businesses and take pride in serving Northern California."
    },
    {
      icon: Zap,
      title: "Flexibility",
      description: "From intimate dinners to large-scale events, we adapt to your needs."
    }
  ];

  return (
    <section id="about" ref={ref} className="py-24 bg-black">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-6xl font-bold text-white mb-6">
              Locally Owned.{" "}
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Community Driven.
              </span>
              <br />
              Service You Can Trust.
            </h2>
          </motion.div>

          {/* Main Content */}
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
            {/* Text Content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="space-y-6"
            >
              <p className="text-lg text-gray-300 leading-relaxed">
                Founded in Sacramento, we're a local staffing company built on one simple promise: 
                to provide reliable, professional event staff that elevate every celebration. We know 
                the hospitality industry inside and out, and we bring that experience to your event — 
                whether it's a wedding in Napa, a corporate gala in San Francisco, or a backyard 
                celebration in Sacramento.
              </p>
              <p className="text-lg text-gray-300 leading-relaxed">
                We're not a national chain — we're your neighbors, and we're committed to making 
                your event effortless and unforgettable.
              </p>
            </motion.div>

            {/* Image */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent z-10"></div>
                <div className="w-full h-96 bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl flex items-center justify-center">
                  <Users className="w-24 h-24 text-white/50" />
                </div>
              </div>
            </motion.div>
          </div>

          {/* Core Values */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-8"
          >
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.8 + index * 0.1 }}
                className="group"
              >
                <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-xl p-6 h-full hover:bg-gray-800/50 transition-all duration-300 hover:scale-105">
                  <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-white to-gray-300 rounded-lg mb-4">
                    <value.icon className="w-6 h-6 text-black" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">{value.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{value.description}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;