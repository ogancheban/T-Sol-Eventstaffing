"use client";

import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { MapPin, Clock, Phone } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const ServiceAreasSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  const areas = [
    {
      region: "Sacramento Area",
      cities: ["Downtown", "Midtown", "Arden", "Elk Grove", "Roseville", "Folsom", "Eldorado Hills", "Davis"],
      color: "from-blue-500 to-blue-700"
    },
    {
      region: "Bay Area",
      cities: ["San Francisco", "Oakland", "Berkeley", "San Jose", "Walnut Creek", "Palo Alto"],
      color: "from-green-500 to-green-700"
    }
  ];

  return (
    <section id="areas" ref={ref} className="py-24 bg-black">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-6xl font-bold text-white mb-6">
              Proudly Serving{" "}
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Sacramento & Bay Area
              </span>
            </h2>
            <p className="text-xl text-gray-400">Communities across Northern California</p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Map/Image */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1706392947751-74e157de81c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYWNyYW1lbnRvJTIwY2FsaWZvcm5pYSUyMHNreWxpbmV8ZW58MXx8fHwxNzU2MTM1MDA5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Sacramento California skyline"
                  className="w-full h-96 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-br from-black/30 to-black/60"></div>
                
                {/* Map Points */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={isInView ? { scale: 1 } : {}}
                    transition={{ duration: 0.5, delay: 0.8 }}
                    className="relative"
                  >
                    <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
                    <div className="absolute -top-8 left-1/2 transform -translate-x-1/2">
                      <span className="bg-white text-black px-2 py-1 rounded text-sm font-bold whitespace-nowrap">
                        Sacramento
                      </span>
                    </div>
                  </motion.div>
                  
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={isInView ? { scale: 1 } : {}}
                    transition={{ duration: 0.5, delay: 1 }}
                    className="relative ml-24 mt-8"
                  >
                    <div className="w-4 h-4 bg-blue-500 rounded-full animate-pulse"></div>
                    <div className="absolute -top-8 left-1/2 transform -translate-x-1/2">
                      <span className="bg-white text-black px-2 py-1 rounded text-sm font-bold whitespace-nowrap">
                        Bay Area
                      </span>
                    </div>
                  </motion.div>
                </div>
              </div>
            </motion.div>

            {/* Service Areas */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="space-y-8"
            >
              {areas.map((area, index) => (
                <motion.div
                  key={area.region}
                  initial={{ opacity: 0, y: 30 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: 0.6 + index * 0.2 }}
                  className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-xl p-6"
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${area.color}`}></div>
                    <h3 className="text-xl font-bold text-white">{area.region}</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {area.cities.map((city) => (
                      <div key={city} className="flex items-center gap-2 text-gray-400">
                        <MapPin className="w-3 h-3" />
                        <span className="text-sm">{city}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              ))}

              {/* Additional Info */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 1 }}
                className="bg-gradient-to-r from-gray-900/50 to-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6"
              >
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-white" />
                    <div>
                      <p className="text-white font-semibold">24/7 Availability</p>
                      <p className="text-gray-400 text-sm">Ready for events any day of the week</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-white" />
                    <div>
                      <p className="text-white font-semibold">Local Support</p>
                      <p className="text-gray-400 text-sm">Sacramento-based team, Northern California coverage</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServiceAreasSection;