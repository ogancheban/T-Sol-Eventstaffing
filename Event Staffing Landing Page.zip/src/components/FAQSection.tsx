"use client";

import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef, useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "./ui/button";

const FAQSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);

  const faqs = [
    {
      question: "What areas do you serve?",
      answer: "We proudly serve Sacramento, Bay Area, and Northern California communities including Downtown Sacramento, San Francisco, Oakland, Berkeley, San Jose, and surrounding areas."
    },
    {
      question: "What is your minimum booking requirement?",
      answer: "We have a 4-hour minimum booking per staff member to ensure quality service and proper preparation for your event."
    },
    {
      question: "Can I book a single bartender?",
      answer: "Yes, we offer customizable staffing solutions. You can book individual staff members or full teams based on your event needs."
    },
    {
      question: "Do you provide alcohol and supplies?",
      answer: "Typically, clients provide alcohol and supplies. However, we can arrange for these items if discussed in advance during the booking process."
    },
    {
      question: "Are your staff insured and background-checked?",
      answer: "Yes, all our staff members are fully insured and have undergone comprehensive background checks for your peace of mind."
    },
    {
      question: "How far in advance should I book?",
      answer: "We recommend booking 2-4 weeks in advance, though we can accommodate last-minute requests based on availability."
    },
    {
      question: "Do you handle setup and cleanup?",
      answer: "Yes, setup and cleanup services are included when booked. Our staff will arrive early to prepare and stay after to handle cleanup."
    }
  ];

  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section ref={ref} className="py-24 bg-gray-950">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-6xl font-bold text-white mb-6">
              Frequently Asked{" "}
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Questions
              </span>
            </h2>
          </motion.div>

          {/* FAQ Items */}
          <div className="space-y-4 mb-16">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.1 * index }}
                className="bg-black/50 backdrop-blur-sm border border-gray-800 rounded-xl overflow-hidden hover:border-gray-600 transition-colors duration-300"
              >
                <button
                  onClick={() => setOpenFAQ(openFAQ === index ? null : index)}
                  className="w-full flex items-center justify-between p-6 text-left"
                >
                  <h3 className="text-lg font-semibold text-white pr-4">{faq.question}</h3>
                  {openFAQ === index ? (
                    <ChevronUp className="w-5 h-5 text-white flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-white flex-shrink-0" />
                  )}
                </button>
                
                <motion.div
                  initial={false}
                  animate={{ height: openFAQ === index ? "auto" : 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="px-6 pb-6">
                    <p className="text-gray-400 leading-relaxed">{faq.answer}</p>
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="text-center"
          >
            <p className="text-gray-400 mb-6">Have more questions?</p>
            <Button
              onClick={scrollToContact}
              size="lg"
              className="bg-white text-black hover:bg-gray-200 transition-all duration-300 transform hover:scale-105 px-8 py-6"
            >
              Contact Us Today
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;