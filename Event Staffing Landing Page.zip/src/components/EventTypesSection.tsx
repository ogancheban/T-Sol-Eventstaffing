"use client";

import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { 
  Building2, 
  Users, 
  Music, 
  Palette, 
  Heart, 
  Gift 
} from "lucide-react";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const EventTypesSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  const eventTypes = [
    {
      icon: Building2,
      title: "Corporate Events",
      description: "Professional staff to impress clients and colleagues.",
      image: "https://images.unsplash.com/photo-1712971404080-87271ce2e473?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3Jwb3JhdGUlMjBldmVudCUyMHNldHVwJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc1NjEzNTAwOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      color: "from-blue-500 to-blue-700"
    },
    {
      icon: Users,
      title: "Private Parties",
      description: "Backyard BBQs, birthdays, milestone celebrations.",
      image: "https://images.unsplash.com/photo-1745573674360-644c2edec427?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwcmVjZXB0aW9uJTIwZWxlZ2FudCUyMHNlcnZpY2V8ZW58MXx8fHwxNzU2MTM1MDA4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      color: "from-purple-500 to-purple-700"
    },
    {
      icon: Music,
      title: "Festivals & Outdoor Events",
      description: "Reliable crews for food, beverage, and guest management.",
      image: "https://images.unsplash.com/photo-1633701945987-d21c145a07b0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdXRkb29yJTIwZmVzdGl2YWwlMjBzdGFmZnxlbnwxfHx8fDE3NTYxMzUwMDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      color: "from-green-500 to-green-700"
    },
    {
      icon: Palette,
      title: "Art Shows & Exhibits",
      description: "Discreet and polished staff for galleries and museum events.",
      image: "https://images.unsplash.com/photo-1725783544345-24b39bad8628?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBiYXJ0ZW5kZXIlMjBldmVudCUyMHNlcnZpY2V8ZW58MXx8fHwxNzU2MTM1MDA3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      color: "from-orange-500 to-orange-700"
    },
    {
      icon: Heart,
      title: "Charity & Fundraising Events",
      description: "Seamless service for nonprofit galas and auctions.",
      image: "https://images.unsplash.com/photo-1707126186357-1690bc6866e1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwd2FpdHN0YWZmJTIwcmVzdGF1cmFudCUyMHNlcnZpY2V8ZW58MXx8fHwxNzU2MTM1MDA3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      color: "from-red-500 to-red-700"
    },
    {
      icon: Gift,
      title: "Special Occasions",
      description: "Weddings, anniversaries, and once-in-a-lifetime celebrations.",
      image: "https://images.unsplash.com/photo-1745573674360-644c2edec427?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwcmVjZXB0aW9uJTIwZWxlZ2FudCUyMHNlcnZpY2V8ZW58MXx8fHwxNzU2MTM1MDA4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      color: "from-pink-500 to-pink-700"
    }
  ];

  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="event-types" ref={ref} className="py-24 bg-gray-950">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-6xl font-bold text-white mb-6">
              Perfect for Every{" "}
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Occasion
              </span>
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              No matter the size or style of your event, our professional staff ensures seamless 
              service and a memorable experience. Serving Sacramento, Bay Area, and Northern California.
            </p>
          </motion.div>

          {/* Event Types Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {eventTypes.map((event, index) => (
              <motion.div
                key={event.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
                className="group cursor-pointer"
              >
                <div className="relative bg-black/50 backdrop-blur-sm border border-gray-800 rounded-xl overflow-hidden hover:scale-105 transition-all duration-300 hover:border-gray-600">
                  {/* Image Background */}
                  <div className="relative h-48 overflow-hidden">
                    <ImageWithFallback
                      src={event.image}
                      alt={event.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-black/60"></div>
                    <div className={`absolute inset-0 bg-gradient-to-br ${event.color} opacity-20`}></div>
                  </div>

                  {/* Content */}
                  <div className="relative p-6">
                    <div className={`inline-flex items-center justify-center w-12 h-12 bg-gradient-to-r ${event.color} rounded-lg mb-4`}>
                      <event.icon className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-3">{event.title}</h3>
                    <p className="text-gray-400 leading-relaxed">{event.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="text-center"
          >
            <Button
              onClick={scrollToContact}
              size="lg"
              className="bg-white text-black hover:bg-gray-200 transition-all duration-300 transform hover:scale-105 px-8 py-6"
            >
              Hire Professional Staff for Your Event Today
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default EventTypesSection;