"use client";

import { motion } from "motion/react";
import { useInView } from "motion/react";
import { useRef } from "react";
import { Check, Clock, MapPin } from "lucide-react";
import { Button } from "./ui/button";

const PricingSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  const pricingData = [
    { role: "Waitstaff", rate: "from $35/hour", popular: false },
    { role: "Bartenders", rate: "from $40/hour", popular: true },
    { role: "Event Captains", rate: "from $45/hour", popular: false }
  ];

  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="pricing" ref={ref} className="py-24 bg-black">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-6xl font-bold text-white mb-6">
              Simple, Transparent{" "}
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Rates
              </span>
            </h2>
            <p className="text-xl text-gray-400">No Hidden Fees</p>
          </motion.div>

          {/* Pricing Cards */}
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {pricingData.map((item, index) => (
              <motion.div
                key={item.role}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
                className={`relative bg-gray-900/50 backdrop-blur-sm border rounded-xl p-6 ${
                  item.popular ? "border-white" : "border-gray-800"
                } hover:scale-105 transition-transform duration-300`}
              >
                {item.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-white text-black px-4 py-1 text-sm font-bold rounded-full">
                      Most Popular
                    </span>
                  </div>
                )}
                <div className="text-center">
                  <h3 className="text-xl font-bold text-white mb-2">{item.role}</h3>
                  <div className="text-3xl font-bold text-white mb-4">{item.rate}</div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Additional Info */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="bg-gray-900/30 backdrop-blur-sm border border-gray-800 rounded-xl p-8 mb-12"
          >
            <div className="grid md:grid-cols-2 gap-8">
              <div className="flex items-start gap-3">
                <Clock className="w-6 h-6 text-white mt-1" />
                <div>
                  <h4 className="text-white font-bold mb-2">Minimum Booking</h4>
                  <p className="text-gray-400">4 hours per staff member</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="w-6 h-6 text-white mt-1" />
                <div>
                  <h4 className="text-white font-bold mb-2">Service Area</h4>
                  <p className="text-gray-400">No travel fees within 50 miles of Sacramento</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="text-center"
          >
            <p className="text-gray-400 mb-6">
              Request a personalized quote today — we'll respond within 24 hours.
            </p>
            <Button
              onClick={scrollToContact}
              size="lg"
              className="bg-white text-black hover:bg-gray-200 transition-all duration-300 transform hover:scale-105 px-8 py-6"
            >
              Get Your Custom Quote
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;